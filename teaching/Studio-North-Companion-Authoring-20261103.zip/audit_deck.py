import csv, hashlib, json, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from pypdf import PdfReader

WORK=Path(__file__).resolve().parent
ROOT=Path(r'C:\Users\longxiu\Documents\ChatGPT\customer-economics-lab')
PPTX=WORK/'output/Studio-North-Agentic-AI-Lab-r3.pptx'
PDF=PPTX.with_suffix('.pdf')
d=json.loads((WORK/'build/deck-data.json').read_text(encoding='utf-8'))
ns={'a':'http://schemas.openxmlformats.org/drawingml/2006/main','p':'http://schemas.openxmlformats.org/presentationml/2006/main','c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
norm=lambda s:re.sub(r'\s+','',s)
rows=lambda p:list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
with zipfile.ZipFile(PPTX) as z:
    names=sorted([n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+.xml',n)],key=lambda n:int(re.search(r'(\d+)\.xml',n).group(1)))
    assert len(names)==33
    xml=[ET.fromstring(z.read(n)) for n in names]
    texts=[' '.join(t.text or '' for t in x.findall('.//a:t',ns)) for x in xml]
    notes=[ET.fromstring(z.read(f'ppt/notesSlides/notesSlide{i}.xml')) for i in range(1,34)]
    note_texts=[' '.join(t.text or '' for t in x.findall('.//a:t',ns)) for x in notes]
    for f in d['faq']:
        idx=25+f['number']
        assert norm(f['prompt']) in norm(texts[idx]), ('FAQ slide',f['number'])
        assert norm(f['prompt']) in norm(note_texts[idx]), ('FAQ notes',f['number'])
    def table_values(i):
        return [[[''.join(t.text or '' for t in cell.findall('.//a:t',ns)) for cell in row.findall('a:tc',ns)] for row in tab.findall('a:tr',ns)] for tab in xml[i-1].findall('.//a:tbl',ns)]
    row_map={r[0]:r[1] for n in (5,6) for r in table_values(n)[0][1:]}
    for source in d['inventory']:assert row_map[source['file']]==f"{source['rows']:,}"
    money=lambda v:f'${float(v):,.2f}' if float(v)>=0 else f'-${abs(float(v)):,.2f}'
    for actual,expected in zip(table_values(20)[0][1:],d['planning']):
        assert actual[1:]==[money(expected[k]) for k in ('ltv_before_cac_mean','icac','value_less_icac')]
    for r in d['current']:
        expected=float(r['incremental_spend'])/(float(r['buyers_treatment'])-float(r['buyers_control']))
        assert abs(expected-float(r['icac']))<1e-8
    chart_names=[n for n in z.namelist() if re.fullmatch(r'ppt/(slides/)?charts/chart\d+.xml',n)]
    assert len(chart_names)==1
    chart=ET.fromstring(z.read(chart_names[0]))
    series=chart.findall('.//c:ser',ns)
    assert len(series)==4
    order=[('search','build_skill'),('partner','build_skill'),('search','save_time'),('partner','save_time')]
    for ser,(channel,need) in zip(series,order):
        vals=[float(v.text) for v in ser.findall('c:val/c:numRef/c:numCache/c:pt/c:v',ns)]
        expected=[round(float(r['icac']),2) for r in sorted(d['holdouts'],key=lambda x:x['test_month']) if r['channel']==channel and r['primary_need']==need]
        assert vals==expected,(vals,expected)
    assert 'MBA 743' not in ' '.join(texts)
    assert sum(len(x.findall('.//a:tbl',ns)) for x in xml)==15
pdf=PdfReader(str(PDF)); assert len(pdf.pages)==33
pdf_text=[p.extract_text() or '' for p in pdf.pages]
for f in d['faq']:assert norm(f['prompt']) in norm(pdf_text[25+f['number']])
for p,h in d['paths'].items():assert sha(ROOT/p)==h,p
assert sha(Path(d['inputs']['run'])/'report/customer-economics-report.pdf')==d['inputs']['report_sha256']
raw_months=rows(Path(d['inputs']['run'])/'tables/customer_month.csv')
sample=[r for r in raw_months if r['cohort_month']=='2024-01-01' and r['age_month']=='2']
assert len(sample)==179
retention_key='retained' if 'retained' in sample[0] else 'is_retained'
assert sum(int(float(r[retention_key])) for r in sample)==126
changed=[]
for i in range(1,34):
    name=f'slide-{i:02}.png'
    if sha(WORK/'build/qa'/name)!=sha(WORK/'build/qa-r3'/name):changed.append(i)
assert changed==[7,16,17,20,25],changed
render=json.loads((WORK/'build/qa-r3/render-receipt.json').read_text(encoding='utf-8-sig'))
assert render['potentialVerticalOverflow']==[]
receipt={'status':'passed','slides':33,'native_tables':15,'native_charts':1,'chart_data_points_checked':24,'chart_numeric_presentation':'iCAC rounded to cents for the editable Excel snapshot; full precision retained in CSVs','full_faq_prompts_on_slide_and_in_notes':7,'new_cohort_view_faq_slide':29,'source_file_count_verified':len(d['paths']),'trace_retention':'126 / 179 = 70.4%','changed_render_slides':changed,'native_powerpoint_rendered':True,'no_vertical_text_overflow_detected':True,'pptx_sha256':sha(PPTX),'pdf_sha256':sha(PDF),'source_report_sha256':d['inputs']['report_sha256'],'source_report_recomputed':False}
(WORK/'build/content-audit.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))
