import csv, hashlib, json, re
from pathlib import Path
ROOT=Path(r'C:\Users\longxiu\Documents\ChatGPT\customer-economics-lab')
WORK=Path(__file__).resolve().parent
RUN=ROOT/'outputs/student-neutral-repro-final2-20261102/run-a'
def read(p):
    return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths={}
def data(name):
    p=RUN/'tables'/name; paths[str(p.relative_to(ROOT))]=sha(p); return read(p)
ucv=json.loads((RUN/'diagrams/ucv-tables.json').read_text())
inventory=[]
for t in ucv['tables']:
    p=ROOT/'data'/t['file']; rows=read(p)
    inventory.append({'file':p.name,'rows':len(rows),'bytes':p.stat().st_size,'source':t['source'],'grain':t['grain'],'columns':t['columns']})
    paths[str(p.relative_to(ROOT))]=sha(p)
brief=(ROOT/'docs/companion-slides.md').read_text(encoding='utf-8')
faq=[{'number':int(m[0]),'title':m[1],'prompt':m[2]} for m in re.findall(r'(\d+)\. \*\*(.*?)\*\*\s+“(.*?)”',brief,re.S)]
assert len(faq)==7
out={'inventory':inventory,'faq':faq,'ucv':ucv,'segmentation':data('segmentation_objective.csv'),'holdouts':data('channel_cac.csv'),'current':data('channel_value_decision.csv'),'cohorts':data('cohort_totals.csv'),'matched':data('cohort_six_month_comparison.csv'),'planning':read(RUN/'report/incremental-planning.csv'),'evidence':json.loads((RUN/'report/version-b-evidence.json').read_text()),'paths':paths}
out['trace']=[r for r in out['cohorts'] if r['cohort_month']=='2024-01-01' and int(r['age_month'])<3]
out['inputs']={'report_sha256':sha(RUN/'report/customer-economics-report.pdf'),'run':str(RUN),'source_slide_sha256':sha(WORK/'source.pptx'),'faq_sha256':sha(ROOT/'docs/companion-slides.md')}
(WORK/'build/deck-data.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({'sources':inventory,'trace':out['trace'],'planning':out['planning'],'faq_count':len(faq)},indent=2))
