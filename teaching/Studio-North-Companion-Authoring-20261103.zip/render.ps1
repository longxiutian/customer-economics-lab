param([string]$Suffix='')
$ErrorActionPreference='Stop'
$taskRoot=$PSScriptRoot
$slideStem='Studio-North-Agentic-AI-Lab'+$Suffix
$pptxPath=Join-Path $taskRoot ('output\'+$slideStem+'.pptx')
$pdfPath=Join-Path $taskRoot ('output\'+$slideStem+'.pdf')
$qaDir=Join-Path $taskRoot ('build\qa'+$Suffix)
New-Item -ItemType Directory -Path $qaDir -Force | Out-Null
$ppt=New-Object -ComObject PowerPoint.Application
$deck=$null
$bounds=@()
try {
    $ppt.DisplayAlerts=1
    $ppt.AutomationSecurity=3
    $deck=$ppt.Presentations.Open($pptxPath,$true,$false,$false)
    $deck.SaveAs($pdfPath,32)
    for($i=1;$i -le $deck.Slides.Count;$i++){
        $slide=$deck.Slides.Item($i)
        $slide.Export((Join-Path $qaDir ('slide-{0:D2}.png' -f $i)),'PNG',1280,720)
        foreach($shape in $slide.Shapes){
            if($shape.HasTextFrame -and $shape.TextFrame.HasText){
                $range=$shape.TextFrame.TextRange
                if($range.BoundHeight -gt $shape.Height+2){
                    $bounds+=@{slide=$i;text=$range.Text;shapeHeight=$shape.Height;boundHeight=$range.BoundHeight}
                }
            }
        }
    }
    @{renderer='Microsoft PowerPoint';version=$ppt.Version;slides=$deck.Slides.Count;pdf=$pdfPath;potentialVerticalOverflow=$bounds} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $qaDir 'render-receipt.json') -Encoding utf8
} finally {
    if($null -ne $deck){$deck.Close()}
    if($ppt.Presentations.Count -eq 0){$ppt.Quit()}
    [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ppt)
}
Write-Output ('Rendered '+$slideStem)
