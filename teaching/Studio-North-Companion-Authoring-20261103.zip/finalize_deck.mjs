import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {finalizePresentation} from 'file:///C:/Users/longxiu/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations/container_tools/artifact_tool_utils.mjs';
const work=path.dirname(new URL(import.meta.url).pathname.replace(/^\/(\w:)/,'$1'));
const skill='C:/Users/longxiu/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations';
const source=path.join(work,'source.pptx');
const ledger=JSON.parse(await fs.readFile(path.join(work,'build/slide-ledger.json'),'utf8'));
const suffix=process.argv[2]||'';
process.env.RUNTIME_NODE_MODULES='C:/Users/longxiu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const result=await finalizePresentation({workspaceDir:work,candidatePath:path.join(work,'build/Studio-North-Agentic-AI-Lab-draft.pptx'),finalPath:path.join(work,`output/Studio-North-Agentic-AI-Lab${suffix}.pptx`),
pythonExecutable:'C:/Users/longxiu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
integrityValidatorPath:skill+'/container_tools/inspect_presentation_package_integrity.py',layoutValidatorPath:skill+'/container_tools/inspect_presentation_layout_geometry.py',
layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit',...ledger.tableOwners.flatMap(n=>['--require-native-table-slide',String(n)])],
requiredNativeTableOwnerSlides:ledger.tableOwners,requiredNativeChartOwnerSlides:ledger.chartOwners,materializeLiteralChartWorkbooks:true,
fontPolicy:{basis:'reference',families:['Arial'],referencePath:source,referenceSha256:crypto.createHash('sha256').update(await fs.readFile(source)).digest('hex')},
verifyArtifactToolImport:true,receiptPath:path.join(work,`build/finalization${suffix}.json`)});
console.log(JSON.stringify(result));
