import fs from 'node:fs/promises';
import path from 'node:path';
import {FileBlob, PresentationFile} from '@oai/artifact-tool';
import {applyPresentationChartFont} from 'file:///C:/Users/longxiu/.codex/plugins/cache/openai-primary-runtime/presentations/26.1026.10807/skills/presentations/container_tools/artifact_tool_utils.mjs';

const work=path.dirname(new URL(import.meta.url).pathname.replace(/^\/(\w:)/,'$1'));
const d=JSON.parse(await fs.readFile(path.join(work,'build/deck-data.json'),'utf8'));
const p=await PresentationFile.importPptx(await FileBlob.load(path.join(work,'source.pptx')));
p.theme.defaultFont='Arial';
p.slides.keep([1]);
const initial=(await p.inspect({kind:'shape,textbox',maxChars:100000})).records;
p.delete(initial.filter(r=>r.position && ![37,61,655].includes(r.position.top)).map(r=>r.id));
const base=p.slides.items[0];
base.speakerNotes.text='';
const ink='#172C38', muted='#576B78', blue='#2993BC', teal='#087F8C', orange='#C66026', gray='#71868D', pale='#EAF4F8';
const sections={concept:blue,case:teal,evidence:gray,decision:orange,faq:orange};
const ledger=[],tableOwners=[],chartOwners=[];
let count=0;
function text(s,txt,x,y,w,h,size=25,color=ink,bold=false,extra={}) {
  const q=s.shapes.add({geometry:'textbox',name:txt.slice(0,65),position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});
  q.text=txt;
  q.text.style={typeface:'Arial',fontSize:size,color,bold,autoFit:'none',wrap:'square',verticalAlignment:'top',insets:0,...extra};
  return q;
}
function slide(title,kind='concept',sources=[],notes='') {
  const s=count===0?base:base.duplicate();
  if(count>0){
    // The base already contains slide-one content: retain its original furniture only.
    const four=s.shapes.items.slice(0,4);
    for(const obj of s.shapes.items.slice(4)) obj.delete();
  }
  s.moveTo(count); count++;
  const furniture=s.shapes.items;
  const titleBox=furniture.find(x=>x.position.top===61);
  titleBox.text=title; titleBox.text.style={typeface:'Arial',fontSize:34,bold:true,color:ink,insets:0,verticalAlignment:'top',autoFit:'none'};
  const rule=furniture.find(x=>x.position.top===37);rule.fill=sections[kind];
  const foot=furniture.find(x=>x.position.top===655 && x.position.left===64);
  foot.position={left:64,top:655,width:930,height:26};foot.text=kind==='faq'?'FAQ · WHAT ELSE TO PROMPT AFTER RUNNING THE SKILL?':({concept:'CONCEPT',case:'CASE APPLICATION',evidence:'EVIDENCE INTERPRETATION',decision:'GROUP DECISION'}[kind]);
  foot.text.style={typeface:'Arial',fontSize:11,bold:true,color:sections[kind],insets:0};
  const num=furniture.find(x=>x.position.top===655 && x.position.left>1000);num.text=String(count);num.text.style={typeface:'Arial',fontSize:12,color:muted,insets:0};
  s.speakerNotes.text=`${notes}\n\n[Sources]\n${sources.join('\n')}\nStudio North: synthetic dataset 5.1; observations end before January 1, 2026. Report Version B.\nSource table hashes are recorded in the companion provenance file.`;
  ledger.push({slide:count,title,kind,sources});return s;
}
function lead(s,txt,y=150){text(s,txt,64,y,1152,75,25);}
function caption(s,txt,y=610){text(s,txt,64,y,1152,32,17,muted);}
function table(s,values,{x=64,y=250,w=1152,h=270,widths,size=22}={}){
  const t=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width:w,height:h,values,...(widths?{columnWidths:widths}:{})});
  for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){
    const cell=t.getCell(r,c);cell.fill=r===0?ink:'#FFFFFF';
    cell.text.style={typeface:'Arial',fontSize:r===0?size-1:size,bold:r===0,color:r===0?'#FFFFFF':ink,verticalAlignment:'middle',insets:9};
  }
  t.borders.assign({fill:'#B9C9D0',width:0.6,style:'solid'});
  t.rows[0].height=48;
  if(!tableOwners.includes(count))tableOwners.push(count);
  return t;
}
function row(s,heading,body,y,kind='concept',h=90){text(s,heading,64,y,315,h,26,sections[kind],true);text(s,body,405,y,811,h,25);}
function node(s,label,x,y,w=280,h=66,color=blue){
  const q=s.shapes.add({geometry:'rect',name:label,position:{left:x,top:y,width:w,height:h},fill:'#FFFFFF',line:{fill:color,width:1.5}});
  q.text=label;q.text.style={typeface:'Arial',fontSize:23,color:ink,bold:true,insets:10,verticalAlignment:'middle',alignment:'center'};return q;
}
function connect(s,a,b,fromSide='right',toSide='left',color=muted){s.shapes.connect(a,b,{kind:'straight',fromSide,toSide,line:{fill:color,width:2},tail:{type:'arrow',width:'med',length:'med'}});}
const dollars=n=>Number(n).toLocaleString('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2});
const label=r=>(r.channel==='search'?'Search':'Partner')+' / '+r.primary_need.replaceAll('_',' ');

// Opening: preserve the existing teaching deck's Arial, white canvas and color system.
{
const s=slide('Studio North: an agentic AI customer-data lab','case',['docs/business_brief.md','docs/companion-slides.md']);
text(s,'Are We Moving in the Right Direction?',64,170,1110,120,48,ink,true);
text(s,'How eight customer datasets become an executive report',64,320,1080,95,32,teal,true);
text(s,'Managing Customer Data · Mod II 2026',64,455,1110,45,25);
text(s,'Synthetic records, explicit methods, and a workflow you can inspect',64,523,1110,65,25,muted);
}
{
const s=slide('How to read the slide colors','concept',['Retained companion teaching style']);
row(s,'Concept','Definitions and distinctions that organize the analysis.',175,'concept');
row(s,'Case application','Studio North, its records and the report-building workflow.',285,'case');
row(s,'Evidence interpretation','What the saved data, calculations and forecasts establish.',395,'evidence');
row(s,'Group decision','A judgment about the business or a prompt for further work.',505,'decision');
}
{
const s=slide('The lab connects the course into one analysis','concept',['docs/companion-slides.md','SKILL.md']);
lead(s,'The agent carries out the work; you inspect the evidence and make the management judgment.');
const a=node(s,'8 CDP datasets',64,270,325,90),b=node(s,'SKILL.md',477,270,325,90),c=node(s,'Executive report',890,270,325,90);connect(s,a,b);connect(s,b,c);
text(s,'UCV and customer journey',64,407,325,55,25,teal,true);
text(s,'Incrementality, cohorts,\nsegmentation and LTV',477,407,325,85,25,teal,true);
text(s,'Evidence, recommendation\nand reproducible appendix',890,407,325,85,25,teal,true);
text(s,'One workflow links the customer information to a directional recommendation.',64,550,1152,65,27,ink,true);
}
{
const s=slide('The business question gives the workflow its purpose','case',['docs/business_brief.md','data/data_manifest.json']);
row(s,'Studio North','A monthly creative-work membership for independent professionals.',165,'case');
row(s,'Customer needs','Ready-to-use templates save time; guided learning builds skills.',285,'case');
row(s,'Customer economics','Monthly renewals and add-on purchases produce contribution over time.',405,'case');
text(s,'Are newer acquisition cohorts creating more value relative to their acquisition cost?',64,540,1152,90,30,ink,true);
}
{
const s=slide('The customer-history exports describe different events','case',['data/data_manifest.json','docs/data_dictionary.md']);
lead(s,'One row means something different in each source. Start by identifying that row unit.');
const names=['people.csv','subscription_periods.csv','transactions.csv','product_events.csv'];
const grains=['One operational customer','One scheduled subscription cycle','One payment or refund event','One product or support interaction'];
table(s,[['Source table','Rows','What one row records'],...names.map((f,i)=>[f,d.inventory.find(r=>r.file===f).rows.toLocaleString('en-US'),grains[i]])],{y:250,h:300,widths:[400,135,617],size:23});
caption(s,'Frozen synthetic exports · January 2024–December 2025 · 5,703 operational customers');
}
{
const s=slide('Four more exports connect experience and acquisition','case',['data/data_manifest.json','docs/data_dictionary.md']);
lead(s,'The acquisition experiments are a separate research sample with their own controls.');
const names=['feedback.csv','campaign_spend.csv','acquisition_attribution.csv','channel_holdouts.csv'];
const grains=['One completed linked survey','One campaign on one spending date','One acquired person and source credit','One randomized arm in one monthly test'];
table(s,[['Source table','Rows','What one row records'],...names.map((f,i)=>[f,d.inventory.find(r=>r.file===f).rows.toLocaleString('en-US'),grains[i]])],{y:250,h:300,widths:[400,135,617],size:23});
caption(s,'All eight CSVs together: 20.89 MB uncompressed · 48 holdout rows = 24 tests × 2 arms');
}
{
const s=slide('Keys connect records; row units determine valid joins','concept',['docs/data_dictionary.md','sql/01_views.sql','diagrams/source-tables.html'], 'This is a compact relationship view. The full field-level ERD is in the report appendix and generated source-tables HTML. Campaign metadata is derived; it is not a ninth raw source.');
const a=node(s,'people',64,190,260,75,teal), b=node(s,'subscription_periods',455,190,330,75,teal),c=node(s,'transactions',915,190,300,75,teal);connect(s,a,b);connect(s,b,c);
text(s,'person_id',335,194,110,30,17,muted);text(s,'period_id',799,194,100,30,17,muted);
const e=node(s,'product_events + feedback',64,355,405,75,teal);connect(s,a,e,'bottom','top');text(s,'person_id',80,298,160,30,17,muted);
const f=node(s,'acquisition_attribution',600,355,300,75,teal),g=node(s,'campaign_spend',950,355,265,75,teal);connect(s,f,g);text(s,'campaign_id',910,438,220,30,17,muted);
text(s,'Attribution links person_id and the first payment. Aggregate campaign spend before joining.',600,478,610,80,24);
text(s,'channel_holdouts stays separate: join its channel-and-need estimates only at the cost/value finale.',64,566,1152,70,25,orange,true);
}
{
const s=slide('The Universal Customer View classifies fields','case',['diagrams/ucv-tables.json','docs/ucv-tables.md']);
const cats=['Identifiers','Engagement','Relationship','Perception'];
text(s,'people.csv',64,150,500,35,25,teal,true);
table(s,[cats,cats.map(k=>d.inventory.find(x=>x.file==='people.csv').columns[k].join('\n')||'—')],{y:197,h:178,size:21});
text(s,'feedback.csv',64,402,500,35,25,teal,true);
table(s,[cats,cats.map(k=>d.inventory.find(x=>x.file==='feedback.csv').columns[k].join('\n')||'—')],{y:447,h:154,size:21});
caption(s,'The workflow generates a complete four-column field table for every source. Missing perceptions remain missing.',613);
}
{
const s=slide('The journey map connects customer goals to evidence','case',['docs/business_brief.md','cohort_lab/diagrams.py','sql/02_friction.sql']);
lead(s,'One broad customer journey makes the service concrete before we analyze its records.');
const stages=['Discover','Join','First useful outcome','Repeat use','Renew'];const ns=stages.map((v,i)=>node(s,v,64+i*235,265,212,82,teal));ns.slice(1).forEach((n,i)=>connect(s,ns[i],n));
table(s,[['Evidence','What it contributes'],['Product events','Observed usage and support interactions'],['Feedback','Reported ease, value and difficulties'],['Renewal records','Whether the paid relationship continues']],{y:405,h:185,widths:[325,827],size:22});
caption(s,'Potential friction is a hypothesis; pre-renewal behavior and feedback supply the diagnostic evidence.');
}
{
const s=slide('The assets folder makes methodological sources inspectable','concept',['docs/sources.md','assets/articles/orduz-2024-cohort-revenue-retention/provenance.json','assets/articles/larsen-2019-customer-acquisition-cost/README.md']);
table(s,[['Source or asset','Role in this report'],['Fader and Hardie (2007; 2010)','Retention heterogeneity and customer-base valuation'],['Orduz (2024)','Gamma revenue structure; a separate neural retention benchmark'],['Larsen (2019)','Background acquisitions, incrementality and acquisition cost'],['Archify, report styles and locks','Diagrams, document design and a reproducible software environment']],{y:180,h:315,widths:[440,712],size:23});
text(s,'The licensed Orduz notebook is bundled with its source, license and hashes. Larsen has a source record and link.',64,535,1152,80,25);
caption(s,'Methods are adapted explicitly. The source assets explain what was borrowed and what the lab changed.');
}
{
const s=slide('Three skill files have distinct responsibilities','concept',['SKILL.md','skills/student-teacher/SKILL.md','skills/executive-report/SKILL.md']);
table(s,[['Skill','Responsibility'],['SKILL.md','Defines the analysis, economic measures, evidence rules and outputs'],['skills/student-teacher/SKILL.md','Introduces the case, displays intermediate outputs and waits for “next step”'],['skills/executive-report/SKILL.md','Specifies the executive narrative, exhibits, citations and technical appendix']],{y:185,h:300,widths:[490,662],size:23});
text(s,'Skills state the instructions. SQL and Python compute the results. The report template turns those results into a document.',64,535,1152,100,28,ink,true);
}
{
const s=slide('Choose a teaching walkthrough or a straight-through run','concept',['docs/student-workflow.md','cohort_lab/student.py','cohort_lab/workflow.py'], 'The pilot feasibility test is instructor-authorized batch mode. The guided class experience uses the separate student-teacher wrapper. This slide describes both supported modes; it does not instruct the agent to advance a real learner without consent.');
row(s,'Guided class experience','Nineteen checkpoints. See actual intermediate tables and charts, discuss the result, then say “next step”.',175,'concept',135);
row(s,'Straight-through run','An explicitly requested batch run completes the analysis, model fitting and report without teaching checkpoints.',350,'concept',135);
text(s,'In the guided version, your final verdict and proposed action are recorded before the report is generated.',64,550,1152,75,26,teal,true);
}
{
const s=slide('Intermediate outputs make the analysis visible','case',['docs/student-workflow.md','cohort_lab/student.py']);
table(s,[['Checkpoint','What the student sees'],['Sources and UCV','Eight inventories, relationships and field-level classifications'],['SQL and observed cohorts','Saved queries, one traced cell and cohort economics'],['Segmentation and acquisition','Comparable grouping evidence and six monthly iCAC waves'],['Model and value','The model explanation, validation and LTV/payback forecasts'],['Recommendation and report','The learner’s judgment, supporting evidence and final PDF']],{y:175,h:350,widths:[375,777],size:23});
text(s,'lesson_state.json preserves your place; learner_choices.json preserves your judgments.',64,565,1152,65,25,teal,true);
}
{
const s=slide('SQL turns event records into a customer clock','concept',['sql/01_views.sql','cohort_lab/analysis.py']);
row(s,'First paid acquisition','Find each person’s first positive successful payment and assign the acquisition month.',165,'concept',95);
row(s,'One customer-month','Aggregate transactions and subscription status before joining them to the monthly customer grid.',285,'concept',105);
row(s,'Cohort and age','Group by joining month and months since acquisition; retain the original acquired-customer denominator.',415,'concept',105);
text(s,'Python pivots the saved SQL aggregate into the displayed cohort triangle.',64,560,1152,65,26,teal,true);
}
{
const s=slide('One report cell can be traced to a saved table','evidence',['tables/cohort_totals.csv','sql/01_views.sql'], 'Displayed rows are the first three observations for the January 2024 cohort, from the canonical SQL output. This is an explanatory excerpt, not a replacement for the full 24-cohort exhibit.');
lead(s,'January 2024 cohort · Original acquired customers: 179');
table(s,[['Calendar month','Age (months)','Retained customers','Retained share'],...d.trace.map(r=>[r.calendar_month.slice(0,7),r.age_month,r.n_retained,(100*Number(r.retained_share)).toFixed(1)+'%'])],{y:250,h:240,widths:[300,230,320,302],size:25});
text(s,'At age 2: 126 retained ÷ 179 acquired = 70.4%',64,530,1152,55,31,teal,true);
caption(s,'Observed inactivity can be zero. Future, unobserved ages stay blank.');
}
{
const s=slide('Segmentation seeks similarity within cells and differences across them','evidence',['tables/segmentation_objective.csv','cohort_lab/decision_metrics.py']);
lead(s,'Compare the same 4,278 eligible customers at the same six-receipt horizon, using two groups per candidate.');
const labels={primary_need:'Stated need',acquisition_channel:'Acquisition channel',age_band:'Age band',region:'Region'};
table(s,[['Grouping','Across-cell share of variation','Within-cell share'],...d.segmentation.map(r=>[labels[r.scheme],(100*Number(r.between_share)).toFixed(1)+'%',(100*Number(r.within_share)).toFixed(1)+'%'])],{y:250,h:270,widths:[360,450,342],size:25});
text(s,'Stated need provides the strongest separation here; substantial variation remains within each group.',64,545,1152,60,26,teal,true);
caption(s,'Outcome: contribution per acquired customer over the first six receipts.',613);
}
{
const s=slide('Monthly holdouts keep acquisition costs current','evidence',['tables/channel_cac.csv','data/channel_holdouts.csv','docs/cac-incrementality.md'], 'Six disjoint monthly enrollment waves, July–December 2025. Four channel-by-need cells, 500 treated and 500 control prospects per test; 31-day follow-up. All completed waves are retained. Current iCAC uses the latest complete test regardless of favorability. Research spending totals $44,000 per wave and $264,000 across six waves, separate from the operating customer panel. Each channel has its own eligible audience and control, not a randomized head-to-head channel test.');
lead(s,'Fresh holdout tests run each month in four channel-by-need cells. Each test follows 500 treatment and 500 control prospects for 31 days.');
const order=[['search','build_skill'],['partner','build_skill'],['search','save_time'],['partner','save_time']];
const colors=[teal,blue,orange,'#8A628F'];const markers=['circle','square','diamond','triangle'];
const chart=s.charts.add('line',{position:{left:70,top:260,width:1110,height:300},categories:['Jul','Aug','Sep','Oct','Nov','Dec'],series:order.map(([channel,need],i)=>({name:label({channel,primary_need:need}),values:d.holdouts.filter(r=>r.channel===channel&&r.primary_need===need).sort((a,b)=>a.test_month.localeCompare(b.test_month)).map(r=>Math.round(Number(r.icac)*100)/100),line:{fill:colors[i],width:3},marker:{symbol:markers[i],size:5,fill:colors[i]}})),hasLegend:true,legend:{position:'bottom',overlay:false,textStyle:{fontSize:18,fill:ink}},xAxis:{textStyle:{fontSize:19,fill:muted},majorGridlines:null},yAxis:{title:{text:'iCAC ($)',textStyle:{fontSize:20,fill:muted}},min:100,max:350,majorUnit:50,numberFormatCode:'$0',textStyle:{fontSize:18,fill:muted},majorGridlines:{fill:'#E4EBEE',width:0.6}},lineOptions:{smooth:false},chartFill:'#FFFFFF'});
applyPresentationChartFont(chart,{fontFamily:'Arial'});chartOwners.push(count);
caption(s,'July–December 2025 point estimates. Latest completed tests update iCAC; intervals are in the report appendix.',592);
}
{
const s=slide('A holdout reconciles credited CAC with iCAC','evidence',['tables/channel_cac_current.csv','docs/cac-incrementality.md','Kim Larsen (2019), You Don’t Know Your Customer Acquisition Cost.']);
lead(s,'December 2025 · Search / build skill · Results complete January 1, 2026');
table(s,[['Evidence','Treatment','Holdout'],['Assigned prospects','500','500'],['First paid buyers','112','39'],['Focal acquisition spending','$11,000','$0']],{y:235,h:235,widths:[540,306,306],size:25});
text(s,'Credited CAC = $11,000 ÷ 112 = $98.21',64,505,1152,50,29);
text(s,'iCAC = $11,000 ÷ (112 − 39) = $150.68',64,564,1152,50,29,teal,true);
caption(s,'The holdout measures background inflow from all other routes. Source: Larsen (2019).',615);
}
{
const s=slide('The cohort model forecasts value from customer histories','concept',['docs/model-specification.md','docs/orduz-benchmark.md','Fader and Hardie (2007; 2010)','Orduz (2024)']);
row(s,'Retention','Shifted Beta-Geometric: persistent differences in dropout risk, with cohort and group information.',165,'concept',105);
row(s,'Revenue and contribution','Gamma revenue among retained customers, combined with variable costs and observed contribution.',295,'concept',105);
row(s,'Chronological validation','Fit through September 2025, then check October–December. Compare with simple and neural benchmarks.',425,'concept',105);
caption(s,'Experiments estimate acquisition cost. They contribute no retention or revenue outcomes to this model.',588);
text(s,'Sources: Fader and Hardie (2007; 2010); Orduz (2024)',64,620,1152,24,16,muted);
}
{
const s=slide('The finale joins current acquisition cost with cohort value','decision',['tables/channel_value_decision.csv','report/incremental-planning.csv','report/version-b-evidence.json']);
lead(s,'Current iCAC comes from December tests. Value comes from the July 2025 operating cohort: six observed receipts, a common 12-receipt horizon.');
table(s,[['Channel / need','Value before CAC','Current iCAC','Value less iCAC'],...d.planning.map(r=>[label(r),dollars(r.ltv_before_cac_mean),dollars(r.icac),dollars(r.value_less_icac)])],{y:260,h:270,widths:[370,270,245,267],size:24});
text(s,'Search / build skill is the leading candidate. Refresh iCAC as testing and spending continue.',64,540,1152,68,27,orange,true);
caption(s,'Planning assumption: additional buyers have the matched cohort’s contribution value. Acquisition cost is deducted once.',615);
}
{
const s=slide('A recommendation has an inspectable evidence chain','concept',['sql/01_views.sql','cohort_lab/decision_metrics.py','cohort_lab/model.py','templates/customer-economics-report-b.tex.j2']);
table(s,[['Step','Saved evidence for Search / build skill'],['Source records','channel_holdouts.csv: 112 treatment buyers and 39 holdout buyers'],['SQL aggregation','channel_cac_current.csv: $150.68 per additional buyer'],['Customer-value forecast','Matched July cohort: $284.03 contribution value before CAC'],['Decision calculation','channel_value_decision.csv: $133.35 value less iCAC'],['Report exhibit','Named recommendation, calculation table and source map']],{y:180,h:365,widths:[315,837],size:23});
text(s,'An AI-written sentence can be checked against the files that support it.',64,582,1152,55,28,teal,true);
}
{
const s=slide('Dependencies turn instructions into executable work','concept',['pyproject.toml','uv.lock','tools/package-lock.json','docs/setup.md']);
table(s,[['Component','What it does','How the version is preserved'],['Python + uv','DuckDB, data analysis, models and figures','pyproject.toml and uv.lock'],['Node + Chromium','Archify diagrams and browser exports','tools/package-lock.json'],['LaTeX + bundled styles','Compile the report into a PDF','Templates, fonts and build manifest'],['Source assets','Explain methods and supply licensed materials','Original source, license and hash records']],{y:180,h:325,widths:[285,390,477],size:23});
text(s,'A coding-agent harness handles the setup and runs the tools. Students guide the analysis through prompts.',64,549,1152,80,27,teal,true);
}
{
const s=slide('Reproducibility preserves the work behind the PDF','concept',['docs/reproducibility.md','scripts/validate_artifacts.py','scripts/verify_reproducibility.py'], 'The delivered Version B report was replayed twice from verified frozen model fits; 131 canonical artifacts matched on this host. This deck update reuses those outputs and does not claim a model refit. Source hashes, code versions, numerical validation and visual inspection are different checks.');
row(s,'Inputs and definitions','Frozen CSVs, documented keys, economic definitions and file hashes.',165,'concept',90);
row(s,'Executable analysis','Saved SQL, code, dependency locks, fitted outputs and source manifests.',280,'concept',95);
row(s,'Document and checks','Editable report source, figures, PDF, validation receipts and visual review.',405,'concept',95);
text(s,'A report replay reuses verified fits. A full run refits the models. Record which actually ran.',64,550,1152,80,27,teal,true);
}
{
const s=slide('The appendix explains how the report was created','case',['Studio-North-Version-B.pdf, SHA256 '+d.inputs.report_sha256,'report/report_manifest.json']);
table(s,[['Where to look in the current report','What it explains'],['Main body: pages 1–15','The business diagnosis, supporting evidence and proposed action'],['Appendix begins: page 16','Technical detail that supports the management narrative'],['Dataset schema: page 37','The synthetic source tables, keys and relationships'],['Dependencies and assets: page 41','The software environment and supporting knowledge assets'],['Skill-driven workflow: page 42','How instructions, code, outputs and report generation connect']],{y:175,h:360,widths:[480,672],size:23});
text(s,'The final artifact is a report plus the evidence needed to review and reproduce it.',64,576,1152,60,28,teal,true);
}
{
const s=slide('Reference List','concept',['docs/sources.md']);
text(s,'Fader, Peter S., and Bruce G. S. Hardie (2007). “How to Project Customer Retention.” Journal of Interactive Marketing, 21(1), 76–90.',64,165,1152,90,25);
text(s,'Fader, Peter S., and Bruce G. S. Hardie (2010). “Customer-Base Valuation in a Contractual Setting: The Perils of Ignoring Heterogeneity.” Marketing Science, 29(1), 85–93.',64,285,1152,120,25);
text(s,'Orduz, Juan Camilo (2024). “Cohort Revenue Retention Analysis with Flax and NumPyro.” Licensed source-notebook edition included in assets/.',64,435,1152,95,25);
text(s,'Larsen, Kim (2019). “You Don’t Know Your Customer Acquisition Cost.” Source record and original article link in assets/.',64,555,1152,80,25);
s.speakerNotes.text+='\nhttps://www.brucehardie.com/papers/021/\nhttps://www.brucehardie.com/papers/022/\nhttps://juanitorduz.github.io/revenue_retention_numpyro/\nhttps://blog.usejournal.com/you-dont-know-your-customer-acquisition-cost-f7bf820f9d4a';
}
{
const s=slide('FAQ: What Else to Prompt after Running the Skill?','faq',['docs/companion-slides.md']);
text(s,'The report is a starting point for further questions.',64,180,1152,85,37,ink,true);
text(s,'Ask the agent to explain a transformation, change the view, compare a model or test a different decision.',64,310,1152,125,31);
text(s,'The following seven prompts are editable and ready to copy.',64,505,1152,80,30,orange,true);
}
const faqTitles=['Describe the datasets through the UCV','Walk through the SQL cohort triangle','Compare four segments within each cohort','Research and test alternative LTV models','Find a more useful segmentation strategy','Identify what could change the recommendation','Adapt the skill to another business'];
for(const [i,f] of d.faq.entries()){
  const s=slide(`FAQ ${i+1}: ${faqTitles[i]}`,'faq',['docs/companion-slides.md'],`Copyable follow-up prompt:\n\n${f.prompt}\n\nThis prompt requests optional future work; the comparison or extension has not been executed by this deck.`);
  const size=f.prompt.length>650?28:31;
  text(s,f.prompt,64,180,1135,360,size);
  if(i===2)text(s,'Search / build skill · Search / save time\nPartner / build skill · Partner / save time',64,545,1152,80,26,teal,true);
  else text(s,'Copy the prompt into the same conversation after completing the report.',64,584,1152,45,22,muted);
}
// The prototype supplies furniture; all inherited notes and body objects were replaced.
await fs.writeFile(path.join(work,'build/slide-ledger.json'),JSON.stringify({slides:ledger,tableOwners,chartOwners,count,source:d.inputs,sourceHashes:d.paths,faq:d.faq},null,2));
await fs.writeFile(path.join(work,'build/deck-proto.json'),JSON.stringify(p.toProto(),null,2));
await fs.writeFile(path.join(work,'build/deck-inspect.json'),JSON.stringify((await p.inspect({kind:'slide,textbox,shape,table,chart,notes',maxChars:1000000})).records,null,2));
await (await PresentationFile.exportPptx(p)).save(path.join(work,'build/Studio-North-Agentic-AI-Lab-draft.pptx'));
console.log(JSON.stringify({slides:count,tableOwners,chartOwners,output:'build/Studio-North-Agentic-AI-Lab-draft.pptx'}));
